# Blincus Python SDK

The Blincus Python SDK provides a simple way to interact with the Blincus API.

## Installation

You can install the package via pip:

```bash
pip install blincus
